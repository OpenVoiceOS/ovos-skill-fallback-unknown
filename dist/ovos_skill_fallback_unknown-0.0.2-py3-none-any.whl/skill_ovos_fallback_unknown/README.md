# <img src='https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/question.svg' card_color='#22a7f0' width='50' height='50' style='vertical-align:bottom'/> Unknown Handler
Capture unrecognized _Utterances_

## About
Mycroft doesn't know how to do or answer everything (yet).  This _fallback_ is how Mycroft lets you know that, unfortunately, it can't help with what you said.


## Category
**Configuration**

## Tags
#fallback
#unknown
#system
